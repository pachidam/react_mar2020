import React from 'react';
import Modal from 'react-modal';

const  PopUp = ({message,onCancel,onDelete,customStyles,isModelOpen})=>{

   return( <Modal
                ariaHideApp={false}
                isOpen={isModelOpen}
                onRequestClose={onCancel}
                style={customStyles}
                contentLabel="Delete Modal">
                    <div className="modal-dialog" role="document">
                            <div className="modal-content">
                                    <div className="modal-header">
                                        <h5 className="modal-title" id="ModalDetailsLabel">Confirm Delete</h5>
                                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="modal-body">
                                    <p>{message}</p>
                                        <p className="debug-url"></p>
                                    </div>
                                    <div className="modal-footer">
                                        <button type="button" className="btn btn-default" onClick={onCancel}>Cancel</button>
                                        <a className="btn btn-danger btn-ok" onClick={onDelete}>Delete</a>
                                    </div>
                            </div>
                    </div>
            </Modal>
        );
}

export default PopUp;
