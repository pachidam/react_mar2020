import React from  'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import ReactTable from 'react-table';
import axios from 'axios';
import PopUp from './popup';
import GroupDetails from './groupdetails';

class ModalGroup extends React.Component{

    constructor(){
        super();
        this.state={
            data:[],//table data
            clickedrowindex:null,
            rowData:{},
            modalIsOpen:false,
            isDeleteModelOpen:false,
            modalToSave:{
               
            },
            bool:true,
            isHomeClicked:true,
            isProfileClicked:false,
            id:null,
            modalObj:{},
            variableData:[],
            tabName:"",
            associationdata:[],
        }
        this.groupdetailsRef = React.createRef();
    }
    handleDelete=()=>{
        this.setState({isDeleteModelOpen:true});
        
    }
    homechangeTab=()=>{
        if(this.state.isHomeClicked){
            return;
        }
        const b = this.state.bool;
        console.log(b);
        console.log("==========");
        this.setState({
            bool:!b,
            isHomeClicked:true,
            isProfileClicked:false,
            tabName:"",
            associationdata:[]
        });
        
    }
    detailschangeTab=()=>{
        if(this.state.isProfileClicked){
            return;
        }
        const b = this.state.bool;
        console.log(b);
        console.log("==========");
        this.setState({
            bool:!b,
            isHomeClicked:false,
            isProfileClicked:true
        });
        console.log(b);
    }
    onPopUpCancel=()=>{
        this.setState({isDeleteModelOpen:false})
    }
    onDelete=()=>{
        const data  = this.state.data;
        axios.delete('http://localhost:8081/modalgroups/'+this.state.rowData.id).then(resp => {
            this.updateData();
            this.setState({isDeleteModelOpen:false})
         }).catch(error => {
             console.log(error);
         }); 
      
    }
    handleEdit=()=>{
        const n = this.state.rowData==null?2:this.state.rowData.id;
        const b = this.state.bool;
        //this.props.history.push('/model/'+n);
        this.setState({
            bool:!b,
            isProfileClicked:true,
            isHomeClicked:false,
            id:n,
            tabName:"Edit Group"
        });
        console.log("updating Model Data here ..................");
        this.updateVariableData();
    }
    updateVariableData=()=>{
                axios.get('http://localhost:8081/modalgroups').then(res => {
                    const arr  = res.data.filter((m)=>m.id==this.state.id) ;
                    this.setState({
                        modalObj:arr[0]
                    });
                    console.log("==============================================");
                    console.log(this.state.modalObj);
                    console.log("==============================================");
                })
      }
    showDialog=()=>{
        //this.props.history.push('/model/new');
       
        const b = this.state.bool;
        this.setState({
            bool:!b,
            isProfileClicked:true,
            isHomeClicked:false,
            id:"new",
            modalObj:{},
            tabName:"New Group",
            associationdata :[]
        });
        console.log("here");
        console.log(this.state.modalObj);
        console.log("here");  
        this.groupdetailsRef.current.clearStates();
    } 
    afterOpenModal=()=> {
        // references are now sync'd and can be accessed.
        
      }
      createModal=()=>{
        axios.post('http://localhost:8081/modalgroups',this.state.modalToSave)
            .then(res => {
                console.log(res);
                console.log(res.data);
                this.setState({modalIsOpen:false});
                this.updateData();
            })
        }
         
      closeModal=()=> {
        this.setState({modalIsOpen: false});
      }
      updateData=()=>{
          console.log("updating table data......");
        axios.get('http://localhost:8081/modalgroups')
        .then(res => {
          this.setState(
              {
                   data:res.data
             });
             console.log("table data changes");
             console.log(res.data);
             console.log("res.data");
        })
       
      }
      getTrProps=(state, rowInfo, column) => {
        const clickedrowindex = this.state.clickedrowindex;
        return{
            onClick:e => {
                        if(rowInfo.index != clickedrowindex){
                            this.setState({
                                clickedrowindex:rowInfo.index,
                                rowData:rowInfo.row._original
                            });
                        }else{
                            this.setState({
                                clickedrowindex:null
                            })
                        }
            },style: {
                background: rowInfo && rowInfo.index === clickedrowindex ? "#D2F2B5" :"white",
            }
        }
      }
        componentDidMount(){
           this.updateData();
        }
        reload=()=>{
            console.log("route changing");
            this.homechangeTab();
            this.updateData();
            console.log(this.state.data);
        }
       
    render(){
            const data = this.state.data;
            console.log(data);
            const clickedrowindex = this.state.clickedrowindex;
            const popucustomstyles = {
                content : {
                top                   : '50%',
                left                  : '50%',
                right                 : 'auto',
                bottom                : 'auto',
                marginRight           : '-50%',
                transform             : 'translate(-50%, -50%)'
                }
            };
            const columns = [
                {
                    Header: "Name",
                    accessor: "name",
                    Cell: this.renderEditable,
                    style: { textAlign: "center" }
                    },{
                        Header: "Modelling System",
                        accessor: "system",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Description",
                        accessor: "description",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Model Association",
                        accessor: "associationcount",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Kind",
                        accessor: "kind",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Monte Carlo",
                        accessor: "montecarlo",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Created By",
                        accessor: "createdBy",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Modified By",
                        accessor: "modifiedBy",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    },{
                        Header: "Created Date",
                        accessor: "createdDate",
                        Cell: this.renderEditable,
                        style: { textAlign: "center" }
                    }
                ];
                const bool = this.state.bool;
        return(
            <div className="mt-5">
                        <div className="nav nav-tabs" id="nav-tab" role="tablist">
                            <a className={bool? "nav-item nav-link active":"nav-item nav-link"} id="nav-home-tab" onClick={this.homechangeTab}
                                data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">ModelGroups</a>
                            <a className={!bool? "nav-item nav-link active":"nav-item nav-link disabled"} onClick={this.detailschangeTab} 
                                id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">{this.state.tabName}</a>
                
                        </div>
            
                            <div className="tab-content" id="nav-tabContent">
                                    <div className={bool?"tab-pane fade show active":"tab-pane fade"} id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                                <div className="card bg-light">
                                                        <div className="card-body">
                                                                <div className="d-flex">
                                                                    <button className="btn btn-outline-info btnFunc ml-auto" 
                                                                            onClick={this.showDialog}><FontAwesomeIcon icon="plus"/>
                                                                    </button>
                                                                    <button className="btn btn-outline-info btnFunc" onClick={this.handleDelete}
                                                                            disabled = {(clickedrowindex==null)? "disabled" : ""}><FontAwesomeIcon icon="trash"/>
                                                                    </button>
                                                                    <button className="btn btn-outline-info btnFunc" onClick={this.handleEdit}
                                                                            disabled = {(clickedrowindex==null)? "disabled" : ""}><FontAwesomeIcon icon="edit"/>
                                                                    </button>
                                                                </div>
                                                                <ReactTable
                                                                        data={data}
                                                                        columns={columns}
                                                                        defaultPageSize={10}
                                                                        getTrProps={this.getTrProps}
                                                                />
                                                            </div>
                                                    </div>
                                        </div>
                                        <div className={!bool?"tab-pane fade show active":"tab-pane fade"} id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                
                                                <GroupDetails 
                                                    id={this.state.id}   
                                                    modalObj={this.state.modalObj}
                                                    reload={this.reload}
                                                    associationdata={this.state.associationdata}
                                                    ref = {this.groupdetailsRef}
                                                    />
                                        </div>
                                
                            </div>
                            <PopUp
                                        message={'You are about to delete one track, this procedure is irreversible.Do you want to proceed?'}
                                        onCancel={this.onPopUpCancel}
                                        onDelete={this.onDelete}
                                        customStyles={popucustomstyles}     
                                        isModelOpen={this.state.isDeleteModelOpen}   
                            />
                    </div>
        );
    }
}

export default ModalGroup;