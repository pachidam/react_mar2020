import React, { useEffect } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import {  makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import TablePagination from '@material-ui/core/TablePagination';
import Checkbox from '@material-ui/core/Checkbox';
import AddIcon from '@material-ui/icons/Add';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import Fab from '@material-ui/core/Fab';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import axios from 'axios';
import Container from '@material-ui/core/Container';

const useStyles = makeStyles(theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing(3),
    },
    paper: {
      width: '100%',
      marginBottom: theme.spacing(2),
    },
    table: {
      minWidth: 750,
    },
    tableWrapper: {
      overflowX: 'auto',
    },
    visuallyHidden: {
      border: 0,
      clip: 'rect(0 0 0 0)',
      height: 1,
      margin: -1,
      overflow: 'hidden',
      padding: 0,
      position: 'absolute',
      top: 20,
      width: 1,
    }, tableWrapper: {
        overflowX: 'auto',
      }
  }));
  
  function createData(name, modelingsystem, description, modelingassociations,kind, montecarlo,createdBy,modifiedby,createddate) {
    return { name, modelingsystem, description, modelingassociations,kind, montecarlo,createdBy,modifiedby,createddate };
  }
//   const rows = [
//     createData('group2', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group3', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group4', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group5', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group6', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group7', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group6', 159, 6.0, 24, 4.0,3,3,3,4),
//     createData('group7', 159, 6.0, 24, 4.0,3,3,3,4)

//   ];
    export default function ModelGroup(){
        const [order, setOrder] = React.useState('asc');
        const classes = useStyles();
        const [rowsPerPage, setRowsPerPage] = React.useState(5);
        const [orderBy, setOrderBy] = React.useState('calories');
        const [selected, setSelected] = React.useState([]);
        const [page, setPage] = React.useState(0);
        const[isRowSelected,setIsRowSelected] = React.useState(false);
        const[rows,setRows] =React.useState([]);

        useEffect(async()=>{
            const res = await axios.get("http://localhost:8081/modelgroups");
           
            const  arr = res.data[0];
            console.log(arr);
            const array =[];
            array.push({arr});

            setRows(res.data);
        },[]);
        const handleChangeRowsPerPage = event => {
            console.log(rowsPerPage);
            setRowsPerPage(parseInt(event.target.value, 10));
            console.log(rowsPerPage);
            setPage(0);
        };
      const isSelected = name => selected.indexOf(name) !== -1;
      const handleChangePage = (event, newPage) => {
        setPage(newPage);
      };
      function getSorting(order, orderBy) {
        return order === 'desc' ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
      }
      function desc(a, b, orderBy) {
        if (b[orderBy] < a[orderBy]) {
          return -1;
        }
        if (b[orderBy] > a[orderBy]) {
          return 1;
        }
        return 0;
      }
      const handleClick = (event, row) => {
          setIsRowSelected(true);
         if( !isSelected(row.name) && selected.length>0){
            setSelected([]);
             return;
         }
        const selectedIndex = selected.indexOf(row.name);
        let newSelected = [];
    
        if (selectedIndex === -1) {
          newSelected = newSelected.concat(selected, row.name);
        } else if (selectedIndex === 0) {
          newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
          newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
          newSelected = newSelected.concat(
            selected.slice(0, selectedIndex),
            selected.slice(selectedIndex + 1),
          );
        }
    
        setSelected(newSelected);
      };

      function stableSort(array, cmp) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
          const order = cmp(a[0], b[0]);
          if (order !== 0) return order;
          return a[1] - b[1];
        });
        return stabilizedThis.map(el => el[0]);
      }
      const handleSelectAllClick = event => {
        if (event.target.checked) {
          const newSelecteds = rows.map(n => n.name);
          setSelected(newSelecteds);
          return;
        }
        setSelected([]);
      };
      const handleRequestSort = (event, property) => {
        const isDesc = orderBy === property && order === 'desc';
        setOrder(isDesc ? 'asc' : 'desc');
        setOrderBy(property);
      };
      const headCells = [
        { id: 'name', numeric: false, disablePadding: true, label: 'Name' },
        { id: 'modelingsystem', numeric: false, disablePadding: false, label: 'Modeling System' },
        { id: 'description', numeric: false, disablePadding: false, label: 'Description' },
        { id: 'modelingassociations', numeric: false, disablePadding: false, label:' Modeling Association' },
        { id: 'kind', numeric: false, disablePadding: false, label: 'Kind' },
        { id: 'montecarlo', numeric: false, disablePadding: false, label: 'Monte Carlo' },
        { id: 'createdBy', createdby: false, disablePadding: false, label: 'Created By' },
        { id: 'modifiedby', modifiedby: false, disablePadding: false, label: 'Modified By' },
        { id: 'createddate', createdate: false, disablePadding: false, label: 'Created Date' }
      ];
      function EnhancedTableHead(props) {
        const { classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort } = props;
        const createSortHandler = property => event => {
          onRequestSort(event, property);
        };
      
        return (
          <TableHead>
            <TableRow>
              <TableCell padding="checkbox">
                    {/* <Checkbox
                    indeterminate={numSelected > 0 && numSelected < rowCount}
                    checked={numSelected === rowCount}
                    onChange={onSelectAllClick}
                    inputProps={{ 'aria-label': 'select all desserts' }}
                    /> */}
              </TableCell>
                    {headCells.map(headCell => (
                        <TableCell
                                key={headCell.id}
                                align={headCell.numeric ? 'right' : 'left'}
                                padding={headCell.disablePadding ? 'none' : 'default'}
                                sortDirection={orderBy === headCell.id ? order : false}>
                        <TableSortLabel
                            active={orderBy === headCell.id}
                            direction={order}
                            onClick={createSortHandler(headCell.id)}>
                            {headCell.label}
                            {orderBy === headCell.id ? (
                            <span className={classes.visuallyHidden}>
                                {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                            </span>) : null}
                        </TableSortLabel>
                        </TableCell>
                    ))}
            </TableRow>
          </TableHead>
        );
      }

    return(
        <div className={classes.root}>
        <Paper className="mt-5">
                <div className="d-flex">
                <Fab color="primary" aria-label="add" className="ml-auto mr-2" >
                <AddIcon/>
                </Fab>
                <Fab color="primary" aria-label="edit"className=" mr-2">
                <EditIcon/>
                </Fab>
                <Fab color="secondary" aria-label="delete" className=" mr-2" >
                <DeleteIcon/>
                </Fab>
                </div>
                <div className={classes.tableWrapper}>
                <Table className={classes.table} aria-label="Model Group">
                <EnhancedTableHead
                    classes={classes}
                    numSelected={selected.length}
                    order={order}
                    orderBy={orderBy}
                    onSelectAllClick={handleSelectAllClick}
                    onRequestSort={handleRequestSort}
                    rowCount={rows.length}
                    />
                    <TableBody>
                        {stableSort(rows, getSorting(order, orderBy))
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map((row, index) => {
                                const isItemSelected = isSelected(row.name);
                                const labelId = "enhanced-table-checkbox-${index}"
                                return (
                                    <TableRow
                                        hover
                                        onClick={event => handleClick(event, row)}
                                        role="checkbox"
                                        aria-checked={isItemSelected}
                                        tabIndex={-1}
                                        key={row.name}
                                        selected={isItemSelected}
                                        >
                                    <TableCell padding="checkbox">
                                        <Checkbox
                                        checked={isItemSelected}
                                        inputProps={{ 'aria-labelledby': labelId }}
                                        />
                                    </TableCell>
                                    <TableCell component="th" id={labelId} scope="row" padding="none">
                                        {row.name}
                                    </TableCell>
                                    <TableCell align="right">{row.modelingsystem}</TableCell>
                                    <TableCell align="right">{row.description}</TableCell>
                                    <TableCell align="right">{row.modelingassociations}</TableCell>
                                    <TableCell align="right">{row.kind}</TableCell>
                                    <TableCell align="right">{row.montecarlo}</TableCell>
                                    <TableCell align="right">{row.createdBy}</TableCell>
                                    <TableCell align="right">{row.modifiedby}</TableCell>
                                    <TableCell align="right">{row.createddate}</TableCell>
                                    </TableRow>);

                                })}
                    </TableBody>
                    </Table>
                    <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={rows.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onChangePage={handleChangePage}
                    onChangeRowsPerPage={handleChangeRowsPerPage}
                    />
                    </div>
        </Paper>
        </div>
    );
}