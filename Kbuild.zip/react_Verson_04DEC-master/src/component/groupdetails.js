import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';
import ReactTable from 'react-table';
import Modal from 'react-modal';
import Select from 'react-select';
import {CheckedSelect} from 'react-select-checked';

class GroupDetails extends React.Component{
  constructor(){
    super();
    this.state={
      id:"",
      modalObj:{},
      isdisabled:true,
      newVariableObj:{},
      isModelOpen:false,
      selectedOption:null,
      associationdata:[],
      isTableDataChanged:false,
      currentSelection:[],
      clickedrowindex:null,
      rowData:{}
    }
    
  }
  clearStates=()=>{
      this.setState({modalObj:{}});
  }
  addToTable = (association)=>{
    let arr = this.state.isTableDataChanged ?this.state.associationdata :association?association:[];
    console.log( arr);
    console.log( association);
    this.state.currentSelection.forEach(element => {
        var obj={};
        obj.association = element.label;
            arr.splice(0, 0, obj);
        
    });
    console.log( arr);
    
   this.setState({
        associationdata:arr,
       currentSelection:[],
       isTableDataChanged:true
    }) ;
  }
  logChange=(val)=>{
    console.log(val);
    this.setState({currentSelection:val});
  }
  handleChange = selectedOption => {
    this.setState({ selectedOption });
    console.log( selectedOption);
    
    
  };
  updateData=()=>{
    
  }
  deleteVariable = ()=>{
    console.log("aa");
  }
  
  enableEditModel = ()=>{
    this.setState({isdisabled:false});
  }
  onCancel=()=>{
    this.setState({isModelOpen:false})
   }
  deleteRow=(data)=>{
        
        let arr = this.state.isTableDataChanged ?this.state.associationdata :data;
        console.log(this.state.rowData.association);
        arr =  arr.filter(i=>{
            return this.state.rowData.association!=i.association
        });
       this.setState({
            associationdata:arr,
            isTableDataChanged:true
       });
       console.log(this.state.associationdata);
    }
    showPopup=()=>{
        this.setState({isModelOpen:true});
    }
  updateModel=(obj)=>{
    if(this.props.id=="new"){
      console.log(this.state.modalObj);
      const id  = Math.floor(Math.random() * Math.floor(1000));
      const object = this.state.modalObj;
      object.id=id;
      object.association = this.state.associationdata;
      object.associationcount = this.state.associationdata.length;
      axios.post('http://localhost:8081/modalgroups',object).then(resp => {  
        //this.setState({isTableDataChanged:false});  
        axios.get('http://localhost:8081/modalgroups').then((res)=>{
            this.props.reload(); 
        })
     }).catch(error => {

         console.log(error);
     });  
    }else{
    
        if(this.state.isTableDataChanged){
            obj.association = this.state.associationdata;
            obj.associationcount = obj.association.length;
        }
      axios.put('http://localhost:8081/modalgroups/'+this.props.id,obj).then(resp => {
                    this.setState({isTableDataChanged:false});
                    this.props.reload(); 
     }).catch(error => {

         console.log(error);
     });  
    }
        
    
  }
  
  
  componentDidMount(){
   
  }
  onPress=(e)=>{
        e.preventDefault();
        console.log(e.target.value);
  }
  updateData=(data)=>{
    console.log(this.props.id);
    if(this.props.id!="new"){
      const id = this.props.id
    this.setState({
      id:id
    })
   
    axios.get('http://localhost:8081/modalgroups')
    .then(res => {
      const arr  = res.data.filter((m)=>m.id==id) ;
     
      this.setState({
        modalObj:arr[0]
        
      })
    })
    }
  }
   
  getTrProps=(state, rowInfo, column) => {
    const clickedrowindex = this.state.clickedrowindex;
    return{
        onClick:e => {
                    if(rowInfo.index != clickedrowindex){
                        this.setState({
                            clickedrowindex:rowInfo.index,
                            rowData:rowInfo.row._original
                        });
                    }else{
                        this.setState({
                            clickedrowindex:null
                        })
                    }
        },style: {
            background: rowInfo && rowInfo.index === clickedrowindex ? "#D2F2B5" :"white",
        }
    }
  }
  componentWillReceiveProps(props) {
      console.log("component recieving props..................");
        this.setState({ associationdata: props.associationdata })
  }
render(){
    const customStyles = {
        content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)'
        }
    };
  const pathId = this.props.id!="new";
  const options = [
    { value: 'model2', label: 'model2' },
    { value: 'model3', label: 'model3' },
    { value: 'model4', label: 'model4' },
  ];   
  const currentSelection     = [{ value: 'model3', label: 'model3' }];                                              
  const obj = this.props.modalObj;
  console.log(this.state.modalObj);
  console.log(obj.name);
  const newVariableObj = this.state.newVariableObj;
  const columns = [
    {
        Header: "Model List",
        accessor: "association",
        Cell: this.renderEditable,
        style: { textAlign: "center" }
        }
    ];
    return(<div>   
                <div className="card">
                    <div className="card-header" id="headingOne">
                        <h2 className="mb-0">
                            <button className="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Group Details
                            </button>
                        </h2>
                    </div>
                    <div className="card-body">
                            <div className="row">
                            <div className="col-sm-6" >
      
                                    <div className="form-group">
                                        <label htmlFor="id">Name</label>
                                        <input type="text" className="form-control" defaultValue={pathId? obj.name:this.state.modalObj.name}
                                        disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        onChange={(e)=>{
                                            e.preventDefault();
                                            if(pathId){
                                                obj.name = e.target.value
                                                this.setState({modalObj:obj});
                                                console.log("hereeeee");
                                                return;
                                            }
                                            const o =  this.state.modalObj;
                                             o.name = e.target.value
                                            this.setState({modalObj:o});
                                        }}/>
                                    </div>
                                    <div className="form-group">
                                        <label>Modelling System</label>
                                        <input type="text" className="form-control" defaultValue={pathId? obj.system:this.state.modalObj.system}
                                        disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        onChange={(e)=>{
                                            if(pathId){
                                                obj.system = e.target.value
                                                this.setState({modalObj:obj});
                                                return;
                                            }
                                            e.preventDefault();
                                            const o =  this.state.modalObj;
                                            o.system = e.target.value
                                            this.setState({modalObj:o});
                                        }}/>
                                    </div>
                                    <div className="form-group">
                                            <label>Description</label>
                                        <input type="text" className="form-control" defaultValue={pathId? obj.description:this.state.modalObj.description}
                                        disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        onChange={(e)=>{
                                            e.preventDefault();
                                            if(pathId){
                                                obj.description = e.target.value
                                                this.setState({modalObj:obj});
                                                return;
                                            }
                                            const o =  this.state.modalObj;
                                            o.description = e.target.value
                                           this.setState({modalObj:o});
                                        }}/>
                                    </div>
                                    <div className="form-group">
                                        <label>Monte Carlo</label>
                                        <input type="text" className="form-control" defaultValue={pathId? obj.montecarlo:this.state.modalObj.montecarlo}
                                        disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        onChange={(e)=>{
                                            e.preventDefault();
                                            if(pathId){
                                                obj.montecarlo = e.target.value
                                                this.setState({modalObj:obj});
                                                return;
                                            }
                                            const o =  this.state.modalObj;
                                            o.montecarlo = e.target.value
                                           this.setState({modalObj:o});
                                        }}/>
                                    </div>
                                    <div className="form-group">
                                        <label>Kind</label>
                                        <input type="text" className="form-control" defaultValue={pathId? obj.kind:this.state.modalObj.kind}
                                        disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        onChange={(e)=>{
                                            e.preventDefault();
                                            if(pathId){
                                                obj.kind = e.target.value
                                                this.setState({modalObj:obj});
                                                return;
                                            }
                                            const o =  this.state.modalObj;
                                            o.kind = e.target.value
                                           this.setState({modalObj:o});
                                        }}/>
                                    </div>
                                </div>
                                <div className="col-sm-6" >
                                     
                                <div className="form-group">
                                        <label>Model Association</label>
                                        <div className="row">
                                            <div className="col-md-8 mb-2">
                                            <CheckedSelect
                                                    name="form-field-name"
                                                    disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                                    value={this.state.currentSelection}
                                                    options={options}
                                                    onChange={this.logChange}
                                        /></div>
                                         <div className="col-md-4 d-flex">
                                                <button className="btn btn-outline-info ml-auto mb-2 mr-2" disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                            onClick={()=>this.addToTable(obj.association)}><FontAwesomeIcon  icon="plus"/></button>
                                            <button className="btn btn-outline-info mb-2 mr-2" 
                                            disabled = {( this.state.clickedrowindex==null) || (pathId && this.state.isdisabled) ? "disabled" : ""}
                                            onClick={()=>this.deleteRow(obj.association)}><FontAwesomeIcon  icon="trash"/></button>
                                         </div>
                                        </div>
                                        
                                        {/* <input type="text" className="form-control" defaultValue={pathId? obj.association:this.state.modalObj.association}
                                        disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        onChange={(e)=>{
                                            e.preventDefault();
                                            if(pathId){
                                                obj.association = e.target.value
                                                this.setState({modalObj:obj});
                                                return;
                                            }
                                            const o =  this.state.modalObj;
                                            o.association = e.target.value
                                           this.setState({modalObj:o});
                                        }}/> */}
                                        <ReactTable
                                                data={this.state.isTableDataChanged?this.state.associationdata: obj.association}
                                                columns={columns}
                                                 defaultPageSize={10}
                                                 getTrProps={this.getTrProps}
                                                 disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}
                                        />
                                    </div>
                                </div>
                               <div className="d-flex">
                                  
                                    <button className="btn btn-outline-info  mr-auto ml-2 mt-2" onClick={this.enableEditModel}
                                            disabled = {(!this.state.isdisabled)? "disabled" : ""} hidden={!pathId ?"hidden":""}>
                                            <FontAwesomeIcon icon="edit"/>&nbsp;Edit</button>
                                        <button className="btn btn-outline-info  ml-2 mt-2" onClick={()=>{this.updateModel(obj)}}
                                            disabled = {(pathId && this.state.isdisabled)? "disabled" : ""}>
                                            <FontAwesomeIcon icon="save"/>&nbsp;Save</button>
                    
                                   </div>
                                   
                            </div>
                    </div>
                </div>
                <Modal
                    ariaHideApp={false}
                    isOpen={this.state.isModelOpen}
                    onRequestClose={this.onCancel}
                    style={customStyles}
                    contentLabel="Model Associations">
                        
                     <ul class="list-group" style={{"max-height":"600px","overflow":"scroll","-webkit-overflow-scrolling":"touch"}}>
                          

                            <li class="list-group-item">Cras justo odio</li>
                            <li class="list-group-item">Dapibus ac facilisis in</li>
                            <li class="list-group-item">Morbi leo risus</li>
                            <li class="list-group-item">Porta ac consectetur ac</li>
                            <li class="list-group-item">Vestibulum at eros</li>
                    </ul>
                    <div className="d-flex">
                    <button type="button" className="btn btn-default mr-auto p-2" onClick={this.onCancel}>Cancel</button>
                     <a className="btn btn-outline-success p-2">Choose</a>
                     </div>
            </Modal>
            </div>);
}


}

export default GroupDetails;