import React from 'react';
// import logo from './logo.svg';
import './App.css';
import DataTable from './component/DataTable';
import NavigationBar from './component/navbar';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import ModalDetails from './component/ModalDetails';
import tab from './component/tab';
import MgroupMaterial from './component/mgroupmaterial';
import ModalGroup from './component/modalgroup';

function App() {
  return (
    <div className="container">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />

  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
       <Router>
          <Switch>
            <Route exact path='/' component={DataTable}/>
            <Route path="/model/:id" component={ModalDetails}/>
            <Route path="/model/new" component={ModalDetails}/>
            <Route path="/tab" component={tab}/>
            <Route path="/mgroupmaterial" component={MgroupMaterial}/>
            <Route path="/modalgroup" component={ModalGroup}/>
          </Switch>
      </Router>
      </div>
  );
  }

  export default App;