// Express Middleware
const helmet = require('helmet')
const cors = require('cors')
const morgan = require('morgan')

const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const { port } = require('../config');
const ifrs_job_stats = require('./api/ifrs_job_stats')
const ifrs_job_logs = require('./api/ifrs_job_logs')
const ifrs_job_run_definition = require('./api/ifrs_job_run_definition')
const data_val_ts_retail = require('./api/data_val_ts_retail')
const pd_lkp_table_data = require('./api/pd_lkp_table_data')

const runJob = require('./api/run_job')

{/*app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)
*/}

// App Middleware
const whitelist = ['http://localhost:3000']
const corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
}
app.use(helmet())
app.use(cors(corsOptions))
app.use(bodyParser.json())
app.use(morgan('combined')) // use 'tiny' or 'combined'

// App Routes - Auth
app.get('/', (request, response) => {
  response.json({ info: 'Node.js, Express, and Postgres API' })
})
app.get('/ifrs_job_stats', ifrs_job_stats.getRunStatus)
app.get('/ifrs_job_logs', ifrs_job_logs.getRunLogs)
app.get('/ifrs_job_run_definition', ifrs_job_run_definition.getRunDefinition)
app.get('/ifrs_job_logs/:id', ifrs_job_logs.getRunLogsbySessionId)
app.get('/data_val_ts_retail', data_val_ts_retail.getDataValTsRetail)
app.get('/pd_retail_rev', pd_lkp_table_data.getPDRetailRev)

app.get('/runJob', runJob.submitJob)

// App Server Connection
app.listen(port, () => {
  console.log(`Your port is ${port}`);
})
