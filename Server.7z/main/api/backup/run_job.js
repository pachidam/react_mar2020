var Client = require('ssh2').Client;
var conn = new Client();
exports.submitJob = function(req, res) {
  conn.on('ready', function() {
    console.log('Client :: ready');
    conn.shell(function(err, stream) {
      res.send(err);

      if (err) throw err;
      stream.on('close', function() {
        console.log('Stream :: close');
        conn.end();
      }).on('data', function(data) {
        console.log('OUTPUT: ' + data);

      });
      stream.write('ls -ltr' + '\n');
      //  stream.write('export SPARK_MAJOR_VERSION=2' + '\n');
      // stream.end('spark-submit --conf spark.network.timeout=10000000 --verbose --name MIP_SAMPLE --master yarn --deploy-mode cluster --driver-memory 10 --executor-memory 10 --num-executors 10 /home/c1524903/Vers/Retail_rev_in_V4_testing.py "2019-09-30" "IN" "RETAIL_REV" \nexit\n');

      stream.end();

    });
  }).connect({
    host: 'hklpatifr13.hk.standardchartered.com',
    port: 22,
    username: 'c1524903',
    password: 'c1524903@321'
  })
};
