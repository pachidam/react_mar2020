const { pgpool } = require('../../config');
const pgcon = pgpool

const getRunLogs = (request, response) => {
  pgcon.query(`select
to_char(reporting_date,'DD-Mon-YYYY') as reporting_date,
trim(country_code) as country_code,
trim(run_id) as run_id,
trim(run_instance)  as run_instance,
trim(instance_id) as instance_id,
trim(log_id) as log_id,
trim(log_level) as log_level,
to_char(run_date, 'DD/MM/YYYY hh24:mi:ss') as run_date,
trim(message) as message
from "IFRS9_HDP_PG_POC".TMP_IFRS_JOB_LOG where instance_id <> '' order by run_date desc `, (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}


const getRunLogsbySessionId = (request, response) => {
  pgcon.query(`select
to_char(reporting_date,'DD-Mon-YYYY') as reporting_date,
trim(country_code) as country_code,
trim(run_id) as run_id,
trim(run_instance)  as run_instance,
trim(instance_id) as instance_id,
trim(log_id) as log_id,
trim(log_level) as log_level,
to_char(run_date, 'DD/MM/YYYY hh24:mi:ss') as run_date,
trim(message) as message
from "IFRS9_HDP_PG_POC".TMP_IFRS_JOB_LOG where instance_id = $1::text order by run_date desc `,[request.params.id], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

module.exports = {
  getRunLogs,
  getRunLogsbySessionId
}
