const { ravipgpool } = require('../../config');
const pgcon = ravipgpool

const getRunDefinition = (request, response) => {
  pgcon.query(`select
trim(run_nm) as run_name,
reporting_date,
trim(country_code) as country_code,
trim(run_id) as run_id,
trim(run_instance)  as run_instance,

trim(cashflows) as cashflows,
trim(counterparties) as counterparties,
trim(economics) as economics,
trim(econsimulations) as econsimulations,
trim(models) as models,
trim(parameters) as parameters,
trim(portfolios) as portfolios,
trim(basepd) as basepd,
trim(scenario_weight) as scenario_weight,
trim(interval) as interval,
trim(pre_processor) as pre_processor,
trim(post_processor) as post_processor,
creation_date,
trim(updt_user) as updt_user
from "IFRS9_HDP_PG_POC".ifrs_job_run_definition`, (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

module.exports = {
  getRunDefinition
}
