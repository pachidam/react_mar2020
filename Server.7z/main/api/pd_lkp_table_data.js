const { ravipgpool } = require('../../config');
const pgcon = ravipgpool

const getPDRetailRev = (request, response) => {
  pgcon.query(`select
*
from "public".pd_lkp_table_data`, (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

module.exports = {
  getPDRetailRev
}
