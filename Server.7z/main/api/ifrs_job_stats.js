const { pgpool } = require('../../config');
const pgcon = pgpool

const getRunStatus = (request, response) => {
  pgcon.query(`select
to_char(reporting_date,'DD-Mon-YYYY') as reporting_date,
trim(country_code) as country_code,
trim(run_id) as run_id,
trim(run_instance)  as run_instance,
trim(session_id) as session_id,
to_char(start_time, 'DD/MM/YYYY hh24:mi:ss') as start_time,
to_char(end_time, 'DD/MM/YYYY hh24:mi:ss') as end_time,
trim(elapsed_time_in_mins) as elapsed_time_in_mins,
upper(status) as status
from "IFRS9_HDP_PG_POC".IFRS_JOB_STATS where session_id <> '' order by start_time::date DESC, start_time::time DESC `, (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

module.exports = {
  getRunStatus
}
