const { ravipgpool } = require('../../config');
const pgcon = ravipgpool

const getDataValTsRetail = (request, response) => {
  pgcon.query(`select segmentid_pd,horizon,env,sum(trim_sum_ead) EAD_SUM,sum(trim_sum_ecl) ECL_SUM,avg(trim_avg_pd) PD_AVG from "IFRS9_HDP_PG_POC".ifr_res_data_valrev_in_ts_demo 
group by segmentid_pd,horizon,env order by segmentid_pd,horizon,env`, (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

module.exports = {
  getDataValTsRetail 
}
