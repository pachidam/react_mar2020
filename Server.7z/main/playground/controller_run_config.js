const getTableData = (req, res, db) => {
  db.select('run_name,run_id,run_type,model_group,model_subset, port_data,econ_data,scen_weight_config,pd_data,run_date,creation_date,run_type,interval,reporting_date,status').from('public.run_config')
    .then(items => {
      if(items.length){
        res.json(items)
      } else {
        res.json({dataExists: 'false'})
      }
    })
    .catch(err => res.status(400).json({dbError: 'db error'}))
}

const postTableData = (req, res, db) => {
  const { run_name } = req.body
  const added = new Date()
  console.log({ run_name })
/*  db('public.run_config').insert({first, last, email, phone, location, hobby, added})
    .returning('*')
    .then(item => {
      res.json(item)
    })
    .catch(err => res.status(400).json({dbError: 'db error'}))
    */
}

/*
const putTableData = (req, res, db) => {
  const { id, first, last, email, phone, location, hobby } = req.body
  db('public.run_config').where({id}).update({first, last, email, phone, location, hobby})
    .returning('*')
    .then(item => {
      res.json(item)
    })
    .catch(err => res.status(400).json({dbError: 'db error'}))
}
*/

module.exports = {
  getTableData,
  postTableData,
  putTableData
}
