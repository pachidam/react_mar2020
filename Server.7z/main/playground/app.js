var createError = require('http-errors');
var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var indexRouter = require ('./routes');
const pg = require('pg');
const PORT = 5001;

var app = express();

const pool = new pg.Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'palani',
  password: 'postgres',
  port: 5432
});
var col1 = '3';
var col2 = 'PostGres';
pool.connect((err, db, done) => {
  if (err) throw err
  db.query('insert into public.test values ($1,$2)', [col1,col2] ,(err, res) => {
    done()
    if (err) {
      console.log(err.stack)
    } else {
      console.log('Inserted Data');
    }
  })
});


pool.connect((err, db, done) => {
  if (err) throw err
  db.query('SELECT * FROM public.test', (err, res) => {
    done()
    if (err) {
      console.log(err.stack)
    } else {
      console.log(res)
    }
  })
});

app.use(logger('dev'));
//app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));
//app.use(express.urlencoded({ extended: false }));
//app.use(cookieParser());
//app.use(express.static(path.join(__dirname, 'public')));
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.listen(PORT, () => console.log('Listening on Port '+PORT));

app.use('/',indexRouter)

module.exports = app;

/*
PATH C:\Users\1520836\WD\Node-v12;C:\ProgramData\Oracle\Java\javapath;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files\1E\NomadBranch\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files (x86)\WhoAmI\;C:\Program Files\Git\cmd;C:\Users\1520836\AppData\Local\Microsoft\WindowsApps;C:\Users\1520836\AppData\Local\atom\bin;
npm config set registry "https://artifactory.global.standardchartered.com/artifactory/api/npm/npm-release"
npm config set registry "http://registry.npmjs.org/"
npm run devstart
*/
