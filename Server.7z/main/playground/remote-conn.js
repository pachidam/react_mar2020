var SSH = require('simple-ssh');

var ssh = new SSH({
    host: 'hklpatifr13.hk.standardchartered.com',
    user: 'c1520836',
    pass: 'palani@331'
});

ssh.exec('ls -lh', {
    out: function(stdout) {
        console.log(stdout);
    }
}).start();
