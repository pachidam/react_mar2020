var Client = require('ssh2').Client;

var conn = new Client();
conn.on('ready', function() {
  console.log('Client :: ready');
  conn.shell(function(err, stream) {
    if (err) throw err;
    stream.on('close', function() {
      console.log('Stream :: close');
      conn.end();
    }).on('data', function(data) {
      console.log('OUTPUT: ' + data);
    });
  //  stream.write('export SPARK_MAJOR_VERSION=2' + '\n');
    //stream.write("spark-submit --conf spark.network.timeout=10000000 --verbose --name MIP_SAMPLE --master yarn --deploy-mode cluster --driver-memory 20g --executor-memory 20g --num-executors 30 /home/c1524903/Vers/Retail_rev_in_V4.py '2019-09-30' 'IN' "+ '\n' );
    stream.end();

    //stream.end('spark-submit --conf spark.network.timeout=10000000 --verbose --name MIP_SAMPLE --master yarn --deploy-mode cluster --driver-memory 10 --executor-memory 10 --num-executors 10 /home/c1524903/Vers/Retail_rev_in_V4_testing.py "2019-09-30" "IN" "RETAIL_REV" \nexit\n');
  });
}).connect({
  host: 'hklpatifr13.hk.standardchartered.com',
  port: 22,
  username: 'c1524903',
  password: 'c1524903@321'
});
