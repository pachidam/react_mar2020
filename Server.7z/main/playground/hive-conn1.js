var hive = require('thrift-hive');
//var assert     = require('assert');
var thrift     = require('thrift');
var transport  =thrift.TBufferedTransport();
var protocol = thrift.TBinaryProtocol();
// Client connection
var client = hive.createClient({
  version: '0.7.1-cdh3u2',
  server: 'hklpatifr12.hk.standardchartered.com',
  port: 9083,
  timeout: 1000
});
// Execute call
client.execute('use default', function(err){
  // Query call
  client.query('show tables')
  .on('row', function(database){
    console.log(database);
  })
  .on('error', function(err){
    console.log(err.message);
    client.end();
  })
  .on('end', function(){
    client.end();
  });
});

/*
URI="jdbc:hive2://hklpadifr07.hk.standardchartered.com:2181,hklpadifr05.hk.standardchartered.com:2181,hklpadifr06.hk.standardchartered.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2
hdfs name service - hdfs://DevHDPC
zookeeper namespace - hiveserver2

spark = SparkSession \
    .builder \
    .appName("MIP_SAMPLE") \
    .config("hive.metastore.uris","thrift://hklpatifr12.hk.standardchartered.com:9083")\
    .config("spark.sparse.lookup.max.row.count", "2") \
        .config('spark.sql.codegen.wholeStage', 'false')\
    .config("spark.sql.shuffle.partitions", "30") \
    .enableHiveSupport()\
    .getOrCreate()

*/
