const dotenv = require('dotenv');
const Pool = require('pg').Pool;
dotenv.config();

const pgpool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  password: process.env.DB_PASS,
  port: process.env.DB_PORT,
})

const ravipgpool = new Pool({
  user: process.env.RDB_USER,
  host: process.env.RDB_HOST,
  database: process.env.RDB_DATABASE,
  password: process.env.RDB_PASS,
  port: process.env.RDB_PORT,
})

module.exports = {
  port: process.env.PORT,
  db_user: process.env.DB_USER,
  db_host:process.env.DB_HOST,
  db_pass:process.env.DB_PASS,
  db_database:process.env.DB_DATABASE,
  db_port: process.env.DB_PORT,
  pgpool:pgpool,
  ravipgpool:ravipgpool
};
